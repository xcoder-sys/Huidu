// 工具函数：将普通字符串转换为Uint8Array字节数组
function stringToBytes(str) {
	var bytes = [];
	for (var i = 0; i < str.length; i++) {
		bytes.push(str.charCodeAt(i));
	}
	return new Uint8Array(bytes);
}

exports.call = function(MPV) {
	var command = null;
	var outputValue = null;

	// 1. 定义28条固定指令的映射 (无变动)
	var hardcodedCommands = {
		'Pos1': stringToBytes("\x04\x00\x01\x00"), // 开屏
		'Pos2': stringToBytes("\x04\x00\x02\x00"), // 关屏
		'Pos3': stringToBytes("\x04\x00\x03\x00"), // 播放
		'Pos4': stringToBytes("\x04\x00\x04\x00"), // 暂停
		'Pos5': stringToBytes("\x04\x00\x06\x00"), // 上一个节目
		'Pos6': stringToBytes("\x04\x00\x07\x00"), // 下一个节目
		'Pos7': stringToBytes("\x04\x00\x09\x00"), // 静音
		'Pos8': stringToBytes("\x04\x00\x0A\x00"), // 音量+
		'Pos9': stringToBytes("\x04\x00\x0B\x00"), // 音量-
		'Pos10': stringToBytes("\x04\x00\x0D\x00"), // 亮度+
		'Pos11': stringToBytes("\x04\x00\x0E\x00"), // 亮度-
		'Pos12': stringToBytes("\x05\x00\x0F\x00\x00"), // 列表循环
		'Pos13': stringToBytes("\x05\x00\x0F\x00\x01"), // 单节目循环
		'Pos14': stringToBytes("\x05\x00\x05\x00\x00"), // 节目1
		'Pos15': stringToBytes("\x05\x00\x05\x00\x01"), // 节目2
		'Pos16': stringToBytes("\x05\x00\x05\x00\x02"), // 节目3
		'Pos17': stringToBytes("\x05\x00\x05\x00\x03"), // 节目4
		'Pos18': stringToBytes("\x05\x00\x05\x00\x04"), // 节目5
		'Pos19': stringToBytes("\x05\x00\x05\x00\x05"), // 节目6
		'Pos20': stringToBytes("\x05\x00\x05\x00\x06"), // 节目7
		'Pos21': stringToBytes("\x05\x00\x05\x00\x07"), // 节目8
		'Pos22': stringToBytes("\x05\x00\x05\x00\x08"), // 节目9
		'Pos23': stringToBytes("\x05\x00\x05\x00\x09"), // 节目10
		'Pos24': stringToBytes("\x05\x00\x05\x00\x0A"), // 节目11
		'Pos25': stringToBytes("\x05\x00\x05\x00\x0B"), // 节目12
		'Pos26': stringToBytes("\x05\x00\x05\x00\x0C"), // 节目13
		'Pos27': stringToBytes("\x05\x00\x05\x00\x0D"), // 节目14
		'Pos28': stringToBytes("\x05\x00\x05\x00\x0E"), // 节目15
	};

	// 2. 从MPV中获取上次的状态 (有修改)
	var previousInputValues = (MPV.PrivateInfo && MPV.PrivateInfo.InputPreviousValue) || {};
	// 将音量默认值设为0，并初始化当前音量变量，用于显示
	var prevVolume = (MPV.PrivateInfo && MPV.PrivateInfo.PrevVolume) || 0;
	var currentVolume = prevVolume; // 初始化当前音量，用于最终输出
	var volumeChanged = false;      // 新增一个标志，判断音量是否变化
	var previousOutputValue = (MPV.PrivateInfo && MPV.PrivateInfo.OutputPreviousValue && MPV.PrivateInfo.OutputPreviousValue.Pos1);

	// 3. 优先处理模拟量输入 (音量调节) (有修改)
	var volInput = MPV.Input["Pos29"];
	if (volInput && volInput.SignalValue !== null && volInput.SignalValue !== undefined) {
		var raw = volInput.SignalValue;
		var norm = Math.max(0, Math.min(65535, raw)) / 65535;
		var vol = Math.round(norm * 100);
		
		// 无论音量是否变化，都更新currentVolume，确保显示的是最新值
		currentVolume = vol;

		if (prevVolume !== vol) {
			// 仅当音量发生变化时，才生成调节指令
			command = new Uint8Array([0x05, 0x00, 0x08, 0x00, vol]);
			volumeChanged = true; // 标记音量已变化，需要刷新显示
		}
	}

	// 4. 处理数字量输入 (无变动)
	if (command === null) {
		var orderedPositions = Object.keys(MPV.Input).sort(function (a, b) {
			return parseInt(b.substring(3)) - parseInt(a.substring(3));
		});

		for (var i = 0; i < orderedPositions.length; i++) {
			var pos = orderedPositions[i];
			var hardcodedCommand = hardcodedCommands[pos];

			if (hardcodedCommand) {
				var isRisingEdge = MPV.Input[pos] && MPV.Input[pos].SignalValue === true && (previousInputValues[pos] === false || previousInputValues[pos] === undefined);

				if (isRisingEdge) {
					command = hardcodedCommand;
					break;
				}
			}
		}
	}

	// 5. 根据指令更新本次输出值 (无变动)
	if (command !== null) {
		outputValue = command;
	} else if (previousOutputValue) {
		outputValue = previousOutputValue;
	}

	// 6. 构建并返回MRV对象 (有修改)
	var refreshList = [];
	if (command !== null) {
		// 如果有任何新指令（包括音量调节指令），则刷新指令输出点
		refreshList.push("Pos1");
	}
	if (volumeChanged) {
		// 如果音量值发生了变化，刷新新增的音量显示输出点
		refreshList.push("VolumeValue");
	}

	var mrv = {
		Output: {
			Pos1: outputValue,             // 原有的指令输出
			VolumeValue: currentVolume     // 【新增】音量值输出点，输出0-100的整数
		},
		PrivateInfo: {
			InputPreviousValue: {},
			OutputPreviousValue: { Pos1: outputValue },
			// 【修正】始终保存最新的音量值，而不是只在变化时保存
			PrevVolume: currentVolume      
		},
		Refresh: refreshList,
		Token: MPV.Token
	};

	// 7. 记录本次输入状态，用于下一次调用 (无变动)
	for (var inputPos in MPV.Input) {
		if (MPV.Input.hasOwnProperty(inputPos)) {
			mrv.PrivateInfo.InputPreviousValue[inputPos] = MPV.Input[inputPos].SignalValue;
		}
	}

	return mrv;
};