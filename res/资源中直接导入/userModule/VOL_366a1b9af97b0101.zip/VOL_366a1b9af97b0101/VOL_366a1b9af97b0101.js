/*
 ©2022-2022 Beijing Tsingli Technology Co., Ltd. All Rights Reserved.
 ©2022-2022 北京清立科技有限公司。保留所有权利。

 文件名称: VOL.js
 功能:模拟量转换音量控制指令
 信号：
 一个模拟量输入: <ain>
 一个串行量输出: <sout>
 一个串行量参数: <sta>
 描述：
 将输入的模拟量值转换成2个字节的音量值并组合静态参数计算一个字节的和校验值，按照指令格式进行音量
 控制指令的输出。

 作者: 于建科
 版本说明:
 修改描述:
 */

exports.call = function(MPV) {
  /* 返回数据MRV基本数据格式定义 */
  var MRV = {
    "Output": {},  //输出数据，包含输出的信号位置和值
    "PrivateInfo": {  //模块内部私有数据存储结构
      "OutputPreviousValue": {}
    },
    "Refresh": [],  //输出刷新信号位置
    "Token": ""
  };
  var sta = MPV["StaticParameter"]["Pos1"]["SignalValue"];
  var Arr = sta.split(",");  //定义静态参数，将静态参数以“,”分隔转化成数组
  var input = (MPV["Input"]["Pos1"]["SignalValue"] - 72) * 100;  //输入的模拟量值通过运算得到-7200~1200的音量值
  var value = "";
  if (input < 0) {  //判断运算后的输入值,如果为负数将值转化成16进制的10进制数值
    value = 65536 + input;
  } else {
    value = input;
  };
  var high, low;
  if (value.length < 3) {  //判断value 的数据长度，将value 数据转换成16进制的高八位“high”和低八位“low”
    high = 0;
    low = value;
  } else {
    high = parseInt(value / 256);
    low = value % 256;
  };
  Arr.push(high, low);  //将“high、low”依次追加到数组的结尾
  var sumArr = 0, checsum = 0;
  for (var i = 0; i < Arr.length; i++) {
    sumArr += parseInt(Arr[i]);
  };
  checsum = sumArr % 256;  //将数组中的元素累加，除以256取余数部分，得到指令中的校验和位
  var sumArr = "";
  for (var i = 0; i < Arr.length; i++) {  //将数组中的元素依次提取，并转化为unioncode 字符进行串连输出
    sumArr += String.fromCharCode(Arr[i]);
  };
  var cmd = String.fromCharCode(165, 171) + sumArr + String.fromCharCode(checsum);  //组合指令完整输出
  MRV["Output"]["Pos1"] = cmd;
  MRV["Refresh"][0] = "Pos1";  //刷新输出
  return MRV;
}; 
                    