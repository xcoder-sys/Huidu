exports.call = function(MPV) {
    var MRV = {
        Output: {},
        PrivateInfo: {
            PrevValues: {}
        },
        Refresh: [],
        Token: ""
    };

    // 恢复上次的状态
    if (MPV.PrivateInfo) {
        MRV.PrivateInfo = MPV.PrivateInfo;
    }

    var maxInput = 8; // 假设有 8 路模拟量输入 Pos1 ~ Pos8

    for (var i = 1; i <= maxInput; i++) {
        var posName = "Pos" + i;
        var inputObj = MPV.Input[posName];
        var v = inputObj && inputObj.SignalValue;

        if (typeof v === "number") {
            // 归一化到 0-1 范围，保留 2 位小数
            var norm = Math.max(0, Math.min(65535, v)) / 65535;
            var fixed = norm.toFixed(2);

            var prev = MRV.PrivateInfo.PrevValues[posName];

            if (prev !== fixed) {
                // 生成指令：set input value:Vn,值;
                var cmd = "set input value:V" + i + "," + fixed + ";";

                MRV.Output["Pos1"] = cmd;
                MRV.Refresh.push("Pos1");

                // 更新保存的值
                MRV.PrivateInfo.PrevValues[posName] = fixed;

                // 只输出一个 → 立即跳出循环
                break;
            }
        }
    }

    return MRV;
};
