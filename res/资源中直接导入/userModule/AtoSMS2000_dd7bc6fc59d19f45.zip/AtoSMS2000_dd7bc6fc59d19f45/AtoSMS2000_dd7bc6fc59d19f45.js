exports.call = function(MPV) {
    var MRV = {
        "Output": {},
        "PrivateInfo": {
        "OutputPreviousValue": {}
        },
        "Refresh": [],
        "Token": ""
    };
// 2. 定义输入和输出的信号位置
    var analogInPos = (MPV.SignalNameVSPos && MPV.SignalNameVSPos.Input && MPV.SignalNameVSPos.Input.analogIn) || "Pos1";
    var valueOutPos = (MPV.SignalNameVSPos && MPV.SignalNameVSPos.Output && MPV.SignalNameVSPos.Output.valueOut) || "Pos1";

    // 3. 获取输入信号的值
    var isRefreshed = false;
    if (MPV.Refresh && Array.isArray(MPV.Refresh)) {
        for (var i = 0; i < MPV.Refresh.length; i++) {
            if (MPV.Refresh[i] === analogInPos) {
                isRefreshed = true;
                break;
            }
        }
    }

    // 只有当输入有刷新时才进行计算
    if (isRefreshed) {
        var inputValue = 0;
        if (MPV.Input && MPV.Input[analogInPos] && typeof MPV.Input[analogInPos].SignalValue !== 'undefined') {
            // 将输入的串行量（字符串）转换为整数
            inputValue = parseInt(MPV.Input[analogInPos].SignalValue, 10);
            
            // 确保转换结果是有效的数字
            if (isNaN(inputValue)) {
                inputValue = 0;
            }
        }

        // 4. 执行核心转换逻辑
        // 确保输入值在 0 到 65535 之间，进行边界处理
        if (inputValue < 0) {
            inputValue = 0;
        } else if (inputValue > 65535) {
            inputValue = 65535;
        }

        var outputValue = inputValue / 65535;

        // 5. 将结果保存到 MRV 并标记刷新
        // toFixed(4) 将结果精确到小数点后4位
        MRV.Output[valueOutPos] = outputValue.toFixed(4).toString();
        MRV.Refresh.push(valueOutPos);
    }
    
    // 6. 返回 MRV
    return MRV;
}
                    