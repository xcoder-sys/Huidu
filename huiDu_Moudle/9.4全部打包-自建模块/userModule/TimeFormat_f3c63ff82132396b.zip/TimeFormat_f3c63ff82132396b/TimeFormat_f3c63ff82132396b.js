/*
文件名称: TimeFormat.js
信号：
一个数字量输入<trig>
一个串行量输出<out>
一个静态参数<string>
描述：
时间模块在输入信号<trig>上升沿获取主机系统时间，并按照<string>参数中定义的符号将“时、分、秒”分割组合输出到<out>。
*/
exports.call = function(MPV) {
    /* 返回数据MRV基本数据格式定义 */
    var MRV = {
        /*输出数据，包含输出的信号位置和值*/
        "Output": {},
        /* 模块内部私有数据存储结构 */
        "PrivateInfo": {
            "OutputPreviousValue": {}
        },
        /* 输出刷新信号位置 */
        "Refresh": [],
        "Token": ""
    };
    var sta = MPV.StaticParameter.Pos1.SignalValue;
    if (MPV["Input"]["Pos1"]["SignalValue"] == true) {
        var date = new Date();
        if (date.getHours() < 10) { //获取系统当前小时，如果小时小于10十位用0补齐
            hh = "0" + (date.getHours());
        } else {
            hh = date.getHours();
        }
        if (date.getMinutes() < 10) { //获取系统当前分钟，如果分钟小于10十位用0补齐
            mm = "0" + (date.getMinutes());
        } else {
            mm = date.getMinutes();
        }
        if (date.getSeconds() < 10) { //获取系统当前秒，如果秒小于10十位用0补齐
            ss = "0" + (date.getSeconds());
        } else {
            ss = date.getSeconds();
        }
        out = hh + sta + mm + sta + ss;
        MRV["Output"]["Pos1"] = out; //以静态参数里定义的分隔符将时、分、秒分割输出 
        MRV["Refresh"][0] = "Pos1";  //刷新输出
    }
    return MRV;
}