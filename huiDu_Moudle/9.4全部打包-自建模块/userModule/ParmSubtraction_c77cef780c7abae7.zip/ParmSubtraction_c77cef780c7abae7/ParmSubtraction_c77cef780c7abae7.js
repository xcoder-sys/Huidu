/*
 文件名称: ParmSubtraction.js
 信号：
 多个模拟量输入: <in1>到<in999>
 多个串行量输出: <out1>到<out999>
 多个模拟量参数: <value1>到<value999>
 描述：
 减法模块在每一个输入模拟量信号<inN>有刷新时、将<inN>的值减去对应参数<valueN>中的值并将计算结果转成字符串对应输出<outN>。
 */
exports.call = function(MPV) {
      /* 返回数据MRV基本数据格式定义 */
      var MRV = {
            /*输出数据，包含输出的信号位置和值*/
            "Output": {},
            /* 模块内部私有数据存储结构 */
            "PrivateInfo": {
                  "OutputPreviousValue": {}
            },
            /* 输出刷新信号位置 */
            "Refresh": [],
            "Token": ""
      };
      /* 临时变量，用于运算 */
      var i, refreshPos = 0;
      for (i = 0; i < MPV["Refresh"].length; i++) {
            refreshPos = MPV["Refresh"][i];
            var sub = MPV["StaticParameter"][refreshPos]["SignalValue"]
            /* 输入有刷新，将输入值减去对应参数中的值并将结果转换成字符串输出*/
            MRV["Output"][refreshPos] = (MPV["Input"][refreshPos]["SignalValue"] - sub).toString();
            /* 刷新输出 */
            MRV["Refresh"][i] = refreshPos;
      }
      return MRV;
}; 