exports.call = function(MPV) {
    var MRV = {
        "Output": {},
        "PrivateInfo": {
        "OutputPreviousValue": {}
        },
        "Refresh": [],
        "Token": ""
    };

    var decimal = MPV["Input"]["Pos1"]["SignalValue"];  //获取十进制数
    MRV["Output"]["Pos1"] = decimal.toString(10);  //将十进制数转换为二进制字符串
    console.log("Output = " + MRV["Output"]["Pos1"]);  //打印模块输出信息
    MRV["Refresh"][0] = "Pos1";  //刷新输出

    return MRV;
}
                    