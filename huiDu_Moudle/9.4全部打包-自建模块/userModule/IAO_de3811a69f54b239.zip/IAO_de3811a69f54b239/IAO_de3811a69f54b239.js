/*
 ©2022-2022 Beijing Tsingli Technology Co., Ltd. All Rights Reserved.
 ©2022-2022 北京清立科技有限公司。保留所有权利。

 文件名称: IAO.js
 功能:模拟量值转换调光值
 信号：
 一个模拟量输入: <ain>
 一个串行量输出: <sout>
 一个串行量参数: <sta>
 描述：
 将输入的模拟量值转换成三个字节的调光值（数值不够高位补零），并组合静态参数计算和校验值。
 将得到的16进制的和校验值转换成十进制的数据、再将得到的四位十进制数据每一位对应一个ASCII
 码值（数值不够高位补零），最后按照指令格式进行调光控制指令的输出。

 作者: 于建科
 版本说明:
 修改描述:
 */

exports.call = function(MPV) {
     /* 返回数据MRV基本数据格式定义 */
     var MRV = {
          "Output": {},  //输出数据，包含输出的信号位置和值
          "PrivateInfo": {  //模块内部私有数据存储结构
               "OutputPreviousValue": {}
          },
          "Refresh": [],  //输出刷新信号位置
          "Token": ""
     };
     var sta = MPV["StaticParameter"]["Pos1"]["SignalValue"];
     var Arr = sta.split(",");  //定义静态参数，将静态参数以“,”分隔转化成数组
     var input = parseInt(MPV["Input"]["Pos1"]["SignalValue"] / 337) + 6;
     /*将输入的模拟量数值转换成调光的范围“6~200”数值*/
     input = input.toString();  //将调光模拟量数值转换成ASCII字符
     if (input.length == 1) {  //判断调光数值的字符长度，数值长度不足三位的高位补零
          input = '00' + input;
     } else if (input.length == 2) {
          input = '0' + input;
     } else if (input.length == 3) {
          input = input;
     }
     for (var i = 0; i < input.length; i++) {  //将三位调光数值转换成 Unicode 编码依次追加到Arr数组后面
          Arr.push(input.charCodeAt(i));
     }
     var checsum = 0;
     for (var i = 0; i < Arr.length; i++) {  //将数组中的元素依次提取，并进行累加计算出校验和数值
          checsum += parseInt(Arr[i]);
     };
     var checsum = checsum.toString();  //将计算的和校验数值转换成ASCII字符
     if (checsum.length == 1) {  //判断校验和数值转换后的字符长度，数值长度不足四位的高位补零
          checsum = '000' + checsum;
     } else if (input.length == 2) {
          checsum = '00' + checsum;
     } else if (input.length == 3) {
          checsum = '0' + checsum;
     } else if (input.length == 4) {
          checsum = checsum;
     } 
     for (var i = 0; i < checsum.length; i++) {  //将四位校验和数值转换成 Unicode 编码追加到Arr数组中
          Arr.push(checsum.charCodeAt(i));
     }
     var sumArr = "";
     for (var i = 0; i < Arr.length; i++) {  //将数组中的元素依次提取，并转化为unioncode 字符进行串连输出
          sumArr += String.fromCharCode(parseInt(Arr[i]));
     };
     var cmd = String.fromCharCode(9) + sumArr + String.fromCharCode(13);  //组合指令完整输出
     MRV["Output"]["Pos1"] = cmd;
     MRV["Refresh"][0] = "Pos1";  //刷新输出
     return MRV;
};                 