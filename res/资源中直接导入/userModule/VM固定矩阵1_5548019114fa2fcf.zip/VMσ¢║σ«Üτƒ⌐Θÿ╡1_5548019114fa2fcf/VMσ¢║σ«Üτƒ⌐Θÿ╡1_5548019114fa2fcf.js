exports.call = function(MPV) {
    var MRV = {
        Output: {},
        PrivateInfo: {
            OutputPreviousValue: {}
        },
        Refresh: [],
        Token: ""
    };

    // 输入和输出映射表
    var Inputs = [
        "1v", // in1 (对应数字量输入1/9)
        "2v", // in2 (对应数字量输入2/10)
        "3v", // in3 (对应数字量输入3/11)
        "4v", // in4 (对应数字量输入4/12)
        "5v", // in5 (对应数字量输入5/13)
        "6v", // in6 (对应数字量输入6/14)
        "7v", // in7 (对应数字量输入7/15)
        "8v"  // in8 (对应数字量输入8/16)
    ];
    var Outputs = [
        "1.", // out1
        "2.", // out2
        "3.", // out3
        "4.", // out4
        "5.", // out5
        "6.", // out6
        "7.", // out7
        "8."  // out8
    ];

    var input_;
    var output_;

    // 遍历 8 路输入
    for (var i = 0; i < 8; i++) {
        var pos1 = "Pos" + (i + 1);  // 第一组
        var pos2 = "Pos" + (i + 9);  // 第二组

        var inputObj1 = MPV.Input[pos1];
        var inputObj2 = MPV.Input[pos2];

        var pos1Active = inputObj1 && inputObj1.SignalValue === true;
        var pos2Active = inputObj2 && inputObj2.SignalValue === true;

        if (pos1Active || pos2Active) {
            input_ = Inputs[i];
            output_ = Outputs[i];
            MRV.Output.Pos1 = input_ + output_;

            if (pos2Active) {
                MRV.Refresh.push("Pos1");
            }
            break; // 避免多路同时触发
        }
    }

    return MRV;
}
