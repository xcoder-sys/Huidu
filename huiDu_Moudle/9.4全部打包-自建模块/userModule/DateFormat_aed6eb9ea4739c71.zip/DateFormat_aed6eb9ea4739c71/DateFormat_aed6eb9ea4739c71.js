/*
文件名称: DateFormat.js
信号：
一个数字量输入<trig>
一个串行量输出<out>
一个静态参数<string>
描述：
日期模块在输入信号<trig>上升沿获取主机系统日期，并按照<string>参数中定义的符号将“年、月、日”分割组合输出到<out>。
*/
exports.call = function(MPV) {
    /* 返回数据MRV基本数据格式定义 */
    var MRV = {
        /*输出数据，包含输出的信号位置和值*/
        "Output": {},
        /* 模块内部私有数据存储结构 */
        "PrivateInfo": {
            "OutputPreviousValue": {}
        },
        /* 输出刷新信号位置 */
        "Refresh": [],
        "Token": ""
    };
    var y, m, d, out, sta = MPV.StaticParameter.Pos1.SignalValue;
    if (MPV["Input"]["Pos1"]["SignalValue"] == true) {
        var date = new Date();
        y = date.getFullYear();  //获取系统年信息
        if (date.getMonth() + 1 < 10) {
            m = "0" + (date.getMonth() + 1);
        } else {
            m = date.getMonth() + 1;  //获取系统月信息，如果月份小于10十位用0补齐
        };
        if (date.getDate() < 10) {  //获取系统日信息，如果日期小于10十位用0补齐
            d = "0" + date.getDate();
        } else {
            d = date.getDate();
        };
        out = y + sta + m + sta + d;
        MRV["Output"]["Pos1"] = out;  //以静态参数里定义的分隔符将时、分、秒分割输出 
        MRV["Refresh"][0] = "Pos1";  //刷新输出
    };
    return MRV;
}; 