function hexStrToBin(str) {
	// 每两个字符转成一个字节
	return str.replace(/(..)/g, (m) => String.fromCharCode(parseInt(m, 16)));
}
exports.call = function(MPV) {
	var MRV = {
		Output: {},
		PrivateInfo: {
			OutputPreviousValue: {},
		},
		Refresh: [],
		Token: "",
	};

	if (MPV["Input"]["Pos1"] && MPV["Input"]["Pos1"]["SignalValue"] == true) {
		// 将对应的指令输出到串行量信号1
		/* MRV["Output"]["Pos1"] =
			"\xFF".repeat(6) +
			MPV["StaticParameter"]["Pos1"]["SignalValue"].repeat(16); */
		var macStr = MPV["StaticParameter"]["Pos1"]["SignalValue"]; // "aabbccddeeff"
		var macBin = hexStrToBin(macStr);
		MRV["Output"]["Pos1"] = "\xFF".repeat(6) + macBin.repeat(16);

		MRV["Refresh"].push("Pos1");
		// 只处理第一个为true的输入，避免冲突
	}
	/* console.log(
		Array.from(MRV["Output"]["Pos1"], c => ("0" + c.charCodeAt(0).toString(16)).slice(-2)).join(" ")
	); */
	return MRV;
}