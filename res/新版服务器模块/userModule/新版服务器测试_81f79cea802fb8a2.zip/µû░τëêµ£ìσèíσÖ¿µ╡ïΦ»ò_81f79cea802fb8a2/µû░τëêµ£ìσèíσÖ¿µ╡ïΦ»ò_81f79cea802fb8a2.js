

/* 信号定义参考: 
   模拟量输入: Pos5 (音量值, 0-65535，将转换为0-100) 
   数字量输入: Pos1-Pos4 (对应下方4条指令) 
 */ 
exports.call = function(MPV) { 
    // 1. 定义4条常用的固定指令
    // 注意：部分指令的参数（如节目页名）是基于通用场景设置的，请根据您的实际情况修改。
    var commands = [
        "play all programs:;",          // Pos1: 播放所有节目
        "pause all programs:;",         // Pos2: 暂停所有节目
        "play previous act:Program1;",  // Pos3: 播放上一个节目 (假设节目页名为 Program1)
        "play next act:Program1;",      // Pos4: 播放下一个节目 (假设节目页名为 Program1)
    ];

    // 初始化MRV对象
    var mrv = {
        Output: {
            Pos1: null, // 所有指令统一从Pos1输出
        },
        PrivateInfo: {
            OutputPreviousValue:
                (MPV.PrivateInfo && MPV.PrivateInfo.OutputPreviousValue) || {},
            PrevVolume: (MPV.PrivateInfo && MPV.PrivateInfo.PrevVolume) || -1,
        },
        Refresh: [],
        Token: MPV.Token,
    };

    // 2. 优先处理模拟量输入 (音量调节)
    var volInput = MPV.Input["Pos5"];
    if (
        volInput &&
        volInput.SignalValue !== null &&
        volInput.SignalValue !== undefined
    ) {
        var raw = volInput.SignalValue;
        // 将 0-65535 的输入值归一化到 0-100
        var norm = Math.max(0, Math.min(65535, raw)) / 65535;
        var vol = Math.round(norm * 100);

        if (mrv.PrivateInfo.PrevVolume !== vol) {
            // 构建设置音量的指令字符串
            var volumeCmd = "set volume:" + vol + ";";
            mrv.Output["Pos1"] = volumeCmd;
            mrv.Refresh.push("Pos1");
            mrv.PrivateInfo.PrevVolume = vol; // 保存本次音量值
            return mrv; // 模拟量触发后直接返回
        }
    }

    // 3. 处理数字量输入 (Pos1 - Pos4)
    // 反向遍历以实现“位置序号最大”的优先级
    for (var i = commands.length - 1; i >= 0; i--) {
        var inputName = "Pos" + (i + 1);
        if (MPV.Input[inputName] && MPV.Input[inputName].SignalValue === true) {
            var commandToSend = commands[i];
            mrv.Output["Pos1"] = commandToSend;
            mrv.Refresh.push("Pos1");
            return mrv; // 找到最高优先级的有效指令后立即返回
        }
    }

    // 4. 如果没有任何信号触发，则保持上次的输出
    if (mrv.PrivateInfo.OutputPreviousValue.Pos1) {
        mrv.Output.Pos1 = mrv.PrivateInfo.OutputPreviousValue.Pos1;
    }
    mrv.PrivateInfo.OutputPreviousValue.Pos1 = mrv.Output.Pos1;

    return mrv;
}