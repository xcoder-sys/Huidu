/*
 文件名称: Assignment.js
 信号：
 一个串行量输入: <sin>
 多个数字量输入: <bin1>到<bin999>
 多个数字量输出: <bout1>到<bout999>
 描述：
赋值模块在每一个输入数字量信号<binN>有刷新时、将<sin>的值对应输出到<boutN>。每一个输入有一个对应输出，所有输入输出相互独立。
 */
exports.call = function(MPV) {
      /* 返回数据MRV基本数据格式定义 */
      var MRV = {
            /*输出数据，包含输出的信号位置和值*/
            "Output": {},
            /* 模块内部私有数据存储结构 */
            "PrivateInfo": {
                  "OutputPreviousValue": {}
            },
            /* 输出刷新信号位置 */
            "Refresh": [],
            "Token": ""
      };
      /* 临时变量，用于运算 */
      var i, infresh, outfresh;
      for (i = 0; i < MPV["Refresh"].length; i++) {
            infresh = MPV["Refresh"][i];
            /*判断数字量输入刷新，且输入为上升沿*/
            if (infresh != "Pos1" && MPV["Input"][infresh]["SignalValue"] == true) {
                  outfresh = "Pos" + (parseInt(infresh.replace("Pos","")) -1)
                  /* 输出信号赋值 */
                  MRV["Output"][outfresh] = MPV["Input"]["Pos1"]["SignalValue"]
                  /* 刷新输出 */
                  MRV["Refresh"][0] = outfresh
            }

      }
      return MRV;
}; 